const elUserForm=document.querySelector('.user-form');
const elUserFormLoginInput=document.querySelector('.user-form-login-input');
const elUserFormPasswordInput=document.querySelector('.user-form-password-input')
// console.log(elUserForm, elUserFormLoginInput);
elUserForm.addEventListener('submit', (evt)=>{
   evt.preventDefault();
   const userFormLoginInput=elUserFormLoginInput.value.trim();
   const userFormPasswordInput=elUserFormPasswordInput.value.trim();
   // console.log(userFormLoginInput,userFormPasswordInput);
   fetch('https://reqres.in/api/login', {
      method: 'POST',
      headers: {
         'Content-Type': 'application/json'
      },
      body:JSON.stringify({
         email: userFormLoginInput,
         password: userFormPasswordInput,
     }),
   }).then((response)=>response.json()).then(data=>{
      if(data?.token) {
         window.localStorage.setItem('token', data.token);
         window.location.replace('index.html');
      } 
   });
})