const token=window.localStorage.getItem('token');
const elLogOut=document.querySelector('.log-out');

if(!token){
   window.location.replace('login.html');
}

const elUsersList=document.querySelector('.users-list');

function renderUsers(arr, node) {
   node.innerHTML=null;
   const newFragment=document.createDocumentFragment();
   arr.forEach(element=>{
      const newLi=document.createElement('li');
      const newAvatar=document.createElement('img');
      const newFullname=document.createElement('p');
      const newEmail=document.createElement('a');
      const newDeleteUser=document.createElement('button');

      newAvatar.src=element.avatar;
      newAvatar.alt=element.first_name+' '+element.last_name+' picture';
      newFullname.textContent=element.first_name+' '+element.last_name;
      newEmail.textContent=element.email;
      newEmail.href='mailto:'+element.email;
      newDeleteUser.textContent='Delete';
      newDeleteUser.setAttribute('class','delete-user')
      newDeleteUser.dataset.userId=element.id;

      newLi.appendChild(newAvatar);
      newLi.appendChild(newFullname);
      newLi.appendChild(newEmail);
      newLi.appendChild(newDeleteUser);

      newFragment.appendChild(newLi);
   });
   node.appendChild(newFragment);
}

let users=[];
async function getUsers() {
   try{
      const response=await fetch('https://reqres.in/api/users?page=1');
      const data=await response.json();
      
      if(data) {
         users=data.data;
         renderUsers(data.data, elUsersList);
      }
   } catch(err) {
      console.error(err);
   }
}

elUsersList.addEventListener('click', (evt)=>{
   if(evt.target.matches('.delete-user')){
      const userId=evt.target.dataset.userId;
      const foundUserId=users.findIndex(element=>element.id==userId);
      fetch('https://reqres.in/api/users/'+foundUserId,{
         method: 'DELETE',
      }).then((response)=>{
         if(response.status==204) {
               users.splice(foundUserId, 1);
               renderUsers(users, elUsersList);
         }
      })
    
   };
})
elLogOut.addEventListener('click', ()=>{
   window.localStorage.removeItem('token');
   window.location.replace('login.html');
});
getUsers();